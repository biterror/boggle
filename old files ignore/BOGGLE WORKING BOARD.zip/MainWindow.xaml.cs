﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Boggle
{

    class Puzzle
    {
        string _tile00;
        string _tile01;
        string _tile02;
        string _tile03;
        string _tile10;
        string _tile11;
        string _tile12;
        string _tile13;
        string _tile20;
        string _tile21;
        string _tile22;
        string _tile23;
        string _tile30;
        string _tile31;
        string _tile32;
        string _tile33;
        string _alltiles;

        public string tile00
        {
            get { return _tile00; }
            set { _tile00 = value; }
        }
        public string tile01
        {
            get { return _tile01; }
            set { _tile01 = value; }
        }
        public string tile02
        {
            get { return _tile02; }
            set { _tile02 = value; }
        }
        public string tile03
        {
            get { return _tile03; }
            set { _tile03 = value; }
        }
        public string tile10
        {
            get { return _tile10; }
            set { _tile10 = value; }
        }
        public string tile11
        {
            get { return _tile11; }
            set { _tile11 = value; }
        }
        public string tile12
        {
            get { return _tile12; }
            set { _tile12 = value; }
        }
        public string tile13
        {
            get { return _tile13; }
            set { _tile13 = value; }
        }
        public string tile20
        {
            get { return _tile20; }
            set { _tile20 = value; }
        }
        public string tile21
        {
            get { return _tile21; }
            set { _tile21 = value; }
        }
        public string tile22
        {
            get { return _tile22; }
            set { _tile22 = value; }
        }
        public string tile23
        {
            get { return _tile23; }
            set { _tile23 = value; }
        }
        public string tile30
        {
            get { return _tile30; }
            set { _tile30 = value; }
        }
        public string tile31
        {
            get { return _tile31; }
            set { _tile31 = value; }
        }
        public string tile32
        {
            get { return _tile32; }
            set { _tile32 = value; }
        }
        public string tile33
        {
            get { return _tile33; }
            set { _tile33 = value; }
        }
        public string alltiles
        {
            get { return _alltiles; }
            set { _alltiles = value; }
        }

        public Puzzle(string letters)
        {
            _tile00 = letters[0].ToString();
            _tile01 = letters[1].ToString();
            _tile02 = letters[2].ToString();
            _tile03 = letters[3].ToString();
            _tile10 = letters[4].ToString();
            _tile11 = letters[5].ToString();
            _tile12 = letters[6].ToString();
            _tile13 = letters[7].ToString();
            _tile20 = letters[8].ToString();
            _tile21 = letters[9].ToString();
            _tile22 = letters[10].ToString();
            _tile23 = letters[11].ToString();
            _tile30 = letters[12].ToString();
            _tile31 = letters[13].ToString();
            _tile32 = letters[14].ToString();
            _tile33 = letters[15].ToString();
            _alltiles = letters;
        }


    }

    class Die
    {
        string _chars;
        public string chars
        {
            get { return _chars; }
            set { _chars = value; }
        }
    }
    class Word
    {
        string _theword;
        int _wordscore;

        public string TheWord
        {
            get { return _theword; }
            set { _theword = value; }
        }
        public int WordScore
        {
            get { return _wordscore; }
            set { _wordscore = value; }
        }
        public Word(string w, int s)
        {
            this._theword = w;
            this._wordscore = s;
        }
    }
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer _timer;
        TimeSpan _time;
        bool GameOn;
        static Random _random = new Random();
        static void Shuffle<T>(T[] array)
        {
            int n = array.Length;
            for (int i = 0; i < n; i++)
            {
                int r = i + (int)(_random.NextDouble() * (n - i));
                T t = array[r];
                array[r] = array[i];
                array[i] = t;
            }
        }

        string[] DieRollsList = new string[16];
        string[] diechars = new string[] { "AAEEGN", "ELRTTY", "AOOTTW", "ABBJOO", "EHRTVW", "CIMOTU", "DISTTY", "EIOSST", "DELRVY", "ACHOPS", "HIMNQU", "EEINSU", "EEGHNW", "AFFKPS", "HLNNRZ", "DEILRX" };
        List<string> BoggleDictionary = new List<string>();
        List<Word> ListOfWordsFoundInCurrentPuzzle = new List<Word>();
        List<int[]> ListOfWordsFoundAsYouType = new List<int[]>();
        Puzzle CurrentPuzzle;
        string[,] Puzzle2DArray = new string[4,4];

        private void LoadDictionary()
        {
            string[] DictionaryWords = System.IO.File.ReadAllLines(@"C:\Users\ipd\Documents\bogglerepos___\Boggle\ospd.txt");
            foreach (string dictionaryword in DictionaryWords)
            {
                BoggleDictionary.Add(dictionaryword);
            }
        }

        private void GenerateNewPuzzle()
        {
            TypedWord.Text = "";
            Random r = new Random();
            for (int i = 0; i < 16; i++)
            {
                Die d = new Die();
                d.chars = diechars[i];
                int ind = r.Next(0, 5);
                DieRollsList[i] = d.chars[ind].ToString();
            }
            Shuffle(DieRollsList);
            die00.Content = DieRollsList[0];
            die01.Content = DieRollsList[1];
            die02.Content = DieRollsList[2];
            die03.Content = DieRollsList[3];
            die10.Content = DieRollsList[4];
            die11.Content = DieRollsList[5];
            die12.Content = DieRollsList[6];
            die13.Content = DieRollsList[7];
            die20.Content = DieRollsList[8];
            die21.Content = DieRollsList[9];
            die22.Content = DieRollsList[10];
            die23.Content = DieRollsList[11];
            die30.Content = DieRollsList[12];
            die31.Content = DieRollsList[13];
            die32.Content = DieRollsList[14];
            die33.Content = DieRollsList[15];
            string PuzzleString = String.Join("", DieRollsList);
            CurrentPuzzle = new Puzzle(PuzzleString);
            WordsFoundListView.Items.Clear();
            ListOfWordsFoundInCurrentPuzzle.Clear();
            CurrentScoreLabel.Content = 0;
            Store2DPuzzleArray();
        }

        private void StartTimer()
        {
            TimeLabel.Content = "2:00";
            _time = TimeSpan.FromSeconds(120);
            TimeLabel.Foreground = Brushes.Green;
            if (GameOn == true)
            {
                _timer.Stop();
            }
            else
            {
                GameOn = true;
            }
            _timer = new DispatcherTimer(new TimeSpan(0, 0, 1), DispatcherPriority.Normal, delegate
            {
                if (_time == TimeSpan.Zero)
                {
                    _timer.Stop();
                    GameOn = false;
                }
                else
                {
                    _time = _time.Add(TimeSpan.FromSeconds(-1));
                    TimeLabel.Content = _time.ToString(@"m\:ss");
                    TimeSpan _timecheckone = TimeSpan.FromSeconds(30);
                    TimeSpan _timechecktwo = TimeSpan.FromSeconds(10);
                    if (_time == _timecheckone)
                    {
                        TimeLabel.Foreground = Brushes.Orange;
                    }
                    if (_time == _timechecktwo)
                    {
                        TimeLabel.Foreground = Brushes.Red;
                    }
                }
            }, Application.Current.Dispatcher);
            _timer.Start();
        }

        private bool ValidateWord(string w)
        {
            if (BoggleDictionary.Contains(w))
            {
                bool validinboard = HighLightWord(w);
                return validinboard;
            }
            else
            {
                BadWordsAreRed();
                return false;
            }
        }

        private void BadWordsAreRed()
        {
            foreach (Label lb in DieGrid.Children)
            {
                if (lb.Background == Brushes.LimeGreen)
                {
                    lb.Background = Brushes.Red;
                }
            }
        }

        private bool HighLightWord(string w)
        {
            foreach (Label lb in DieGrid.Children)
            {
                    lb.Background = Brushes.White;
            }
            bool result = false;
            bool WereDoneHere = false;
            string WordToHighLight = TypedWord.Text.ToUpper();
            ListOfWordsFoundAsYouType.Clear();

            if (WordToHighLight.Length > 0)
            {
                int i = 0;
                foreach (char c in CurrentPuzzle.alltiles)
                {
                    int[] WordFound = { 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, };
                    if (c == WordToHighLight[0])
                    {
                        WordFound[i] = 0;
                        ListOfWordsFoundAsYouType.Add(WordFound);
                    }
                    i++;
                }
                for (int j=1; j<WordToHighLight.Length; j++)
                {
                    List<int[]> NewWordsCollector = new List<int[]>();
                    // for each letter user types
                    foreach (int[] WordInProgress in ListOfWordsFoundAsYouType)
                    {
                        // take each word being remembered
                        if (WordInProgress.Contains(j-1))
                        {
                            // if it contains the preveous char
                            for (int k=0; k<16; k++) // k represents char in the puzzle
                            {
                                if (WordInProgress[k] == j - 1)
                                {
                                    // go over each char in the puzzle AND....
                                    if (k <= 11) //CHECK RIGHT
                                    {
                                        int checkdiff = k + 4;
                                        if ((WordToHighLight[j] == CurrentPuzzle.alltiles[checkdiff]) && WordInProgress[checkdiff] == 99)
                                        {
                                            int[] WordFound = { 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, };
                                            Array.Copy(WordInProgress, WordFound, 16);
                                            WordFound[checkdiff] = j;
                                            result = true;
                                            NewWordsCollector.Add(WordFound);
                                        }
                                    }
                                    if (k % 4 < 3) //CHECK DOWN
                                    {
                                        int checkdiff = k + 1;
                                        if ((WordToHighLight[j] == CurrentPuzzle.alltiles[checkdiff]) && WordInProgress[checkdiff] == 99)
                                        {
                                            int[] WordFound = { 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, };
                                            Array.Copy(WordInProgress, WordFound, 16);
                                            WordFound[checkdiff] = j;
                                            result = true;
                                            NewWordsCollector.Add(WordFound);
                                        }
                                    }
                                    if (k >= 4) //CHECK LEFT
                                    {
                                        int checkdiff = k - 4;
                                        if ((WordToHighLight[j] == CurrentPuzzle.alltiles[checkdiff]) && WordInProgress[checkdiff] == 99)
                                        {
                                            int[] WordFound = { 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, };
                                            Array.Copy(WordInProgress, WordFound, 16);
                                            WordFound[checkdiff] = j;
                                            result = true;
                                            NewWordsCollector.Add(WordFound);
                                        }
                                    }
                                    if (k % 4 > 0) //CHECK UP
                                    {
                                        int checkdiff = k - 1;
                                        if ((WordToHighLight[j] == CurrentPuzzle.alltiles[checkdiff]) && WordInProgress[checkdiff] == 99)
                                        {
                                            int[] WordFound = { 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, };
                                            Array.Copy(WordInProgress, WordFound, 16);
                                            WordFound[checkdiff] = j;
                                            result = true;
                                            NewWordsCollector.Add(WordFound);
                                        }
                                    }

                                    if ((k >= 4) && (k % 4 > 0)) //CHECK LEFT UP
                                    {
                                        int checkdiff = k - 5;
                                        if ((WordToHighLight[j] == CurrentPuzzle.alltiles[checkdiff]) && WordInProgress[checkdiff] == 99)
                                        {
                                            int[] WordFound = { 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, };
                                            Array.Copy(WordInProgress, WordFound, 16);
                                            WordFound[checkdiff] = j;
                                            result = true;
                                            NewWordsCollector.Add(WordFound);
                                        }
                                    }
                                    if ((k >= 4) && (k % 4 < 3)) //CHECK LEFT DOWN
                                    {
                                        int checkdiff = k - 3;
                                        if ((WordToHighLight[j] == CurrentPuzzle.alltiles[checkdiff]) && WordInProgress[checkdiff] == 99)
                                        {
                                            int[] WordFound = { 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, };
                                            Array.Copy(WordInProgress, WordFound, 16);
                                            WordFound[checkdiff] = j;
                                            result = true;
                                            NewWordsCollector.Add(WordFound);
                                        }
                                    }
                                    if ((k <= 11) && (k % 4 > 0)) //CHECK RIGHT UP
                                    {
                                        int checkdiff = k + 3;
                                        if ((WordToHighLight[j] == CurrentPuzzle.alltiles[checkdiff]) && WordInProgress[checkdiff] == 99)
                                        {
                                            int[] WordFound = { 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, };
                                            Array.Copy(WordInProgress, WordFound, 16);
                                            WordFound[checkdiff] = j;
                                            result = true;
                                            NewWordsCollector.Add(WordFound);
                                        }
                                    }
                                    if ((k <= 11) && (k % 4 < 3)) //CHECK RIGHT DOWN
                                    {
                                        int checkdiff = k + 5;
                                        if ((WordToHighLight[j] == CurrentPuzzle.alltiles[checkdiff]) && WordInProgress[checkdiff] == 99)
                                        {
                                            int[] WordFound = { 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, 99, };
                                            Array.Copy(WordInProgress, WordFound, 16);
                                            WordFound[checkdiff] = j;
                                            result = true;
                                            NewWordsCollector.Add(WordFound);
                                        }
                                    }
                                }
                            }
                        }
                    }
                    foreach (int[] newword in NewWordsCollector)
                    {
                        ListOfWordsFoundAsYouType.Add(newword);
                    }
                }
            }
            foreach (int[] WordInProgress in ListOfWordsFoundAsYouType)
            {
                if ((WordInProgress.Contains(WordToHighLight.Length - 1)) && (WereDoneHere==false))
                {
                    for (int k = 0; k < 16; k++)
                    {
                        if (WordInProgress[k] != 99)
                        {
                            switch (k)
                            {
                                case 0:
                                    die00.Background = Brushes.LimeGreen;
                                    break;
                                case 1:
                                    die01.Background = Brushes.LimeGreen;
                                    break;
                                case 2:
                                    die02.Background = Brushes.LimeGreen;
                                    break;
                                case 3:
                                    die03.Background = Brushes.LimeGreen;
                                    break;
                                case 4:
                                    die10.Background = Brushes.LimeGreen;
                                    break;
                                case 5:
                                    die11.Background = Brushes.LimeGreen;
                                    break;
                                case 6:
                                    die12.Background = Brushes.LimeGreen;
                                    break;
                                case 7:
                                    die13.Background = Brushes.LimeGreen;
                                    break;
                                case 8:
                                    die20.Background = Brushes.LimeGreen;
                                    break;
                                case 9:
                                    die21.Background = Brushes.LimeGreen;
                                    break;
                                case 10:
                                    die22.Background = Brushes.LimeGreen;
                                    break;
                                case 11:
                                    die23.Background = Brushes.LimeGreen;
                                    break;
                                case 12:
                                    die30.Background = Brushes.LimeGreen;
                                    break;
                                case 13:
                                    die31.Background = Brushes.LimeGreen;
                                    break;
                                case 14:
                                    die32.Background = Brushes.LimeGreen;
                                    break;
                                case 15:
                                    die33.Background = Brushes.LimeGreen;
                                    break;
                            }
                            WereDoneHere = true;
                        }
                    }
                }
            }
            return result;
        }

        private void Store2DPuzzleArray()
        {
            int k=0;
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++) 
                {
                    Puzzle2DArray[i, j] = CurrentPuzzle.alltiles[k].ToString();
                }
            }
        }
        private int[,] MakeWordInProgress2DArray(int[] WordInProgress)
        {
            int k = 0;
            int[,] WordInProgress2DArray = new int[4,4];
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    WordInProgress2DArray[i, j] = WordInProgress[k];
                }
            }
            return WordInProgress2DArray;
        }

        private void AddWordToScore(string w)
        {
            int score = 0;
            int totalscore = 0;
            if (w.Length < 5)
            {
                score = 1;
            } else if (w.Length < 6)
            {
                score = 2;
            } else if (w.Length < 7)
            {
                score = 3;
            } else if (w.Length < 8)
            {
                score = 5;
            } else
            {
                score = 11;
            }
            Word word = new Word(w, score);
            List<string> TempCheck = new List<string>();
            foreach (Word wt in ListOfWordsFoundInCurrentPuzzle) 
            {
                TempCheck.Add(wt.TheWord);
            }
            if (!TempCheck.Contains(w))
            {
                ListOfWordsFoundInCurrentPuzzle.Add(word);
                WordsFoundListView.Items.Add(word);
                foreach (Word ws in ListOfWordsFoundInCurrentPuzzle)
                {
                    totalscore = totalscore + ws.WordScore;
                }
                CurrentScoreLabel.Content = totalscore;
            }
            WordsFoundListView.ScrollIntoView(word);
        }

        public MainWindow()
        {
            InitializeComponent();
            LoadDictionary();
        }

        private void StartButton_Click(object sender, RoutedEventArgs e)
        {
            GenerateNewPuzzle();
            StartTimer();
            TypedWord.Focus();
        }

        private void TypedWord_KeyUp(object sender, KeyEventArgs e)
        {
            HighLightWord(TypedWord.Text.ToUpper());
            if ((e.Key == Key.Enter) && (GameOn == true) && (TypedWord.Text.Length>2))
            {
                string WordInput = TypedWord.Text.ToUpper();
                bool valid = ValidateWord(WordInput);
                TypedWord.Text = "";
                if (valid == true)
                {
                    AddWordToScore(WordInput);
                }
            }
        }
    }
}
